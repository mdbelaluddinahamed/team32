
jQuery(".all_slides").owlCarousel({
    singleItem: true,
    pagination: false,
    autoPlay: 5000,
    theme: "homepage-slider-arrows",
    navigation: true,
    addClassActive: true,
    transitionStyle : "fade",
    navigationText: ["<i class='fa fa-angle-left'></i>","<i class='fa fa-angle-right'></i>"],
    afterMove: previousslide,
    beforeMove: nextslide,
});
 
function previousslide() {
    jQuery(".owl-item.active .slide-container h2").addClass('animated bounce');
}
function nextslide() {
     jQuery(".owl-item .slide-container h2").removeClass('animated bounce');
}