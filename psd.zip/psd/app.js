

jQuery(window).load(function(){
  $('.preloader').fadeOut();
});
jQuery(document).ready(function(){
  
    $('#testislide').owlCarousel({

    navigation: false, // Show next and prev buttons
    slideSpeed: 600,
    pagination: true,
    singleItem: true

  });
  
   $('#client-carousel').owlCarousel({

    navigation: false, // Show next and prev buttons
    slideSpeed: 600,
    items:4,
    pagination: true,
    rewindNav: true,
    itemsDesktop: [1199, 3],
    itemsDesktopSmall: [979, 3],
    stopOnHover: true,
    autoPlay: true

  });
  
  
    $('#slide-carousel').owlCarousel({

    navigation: true, // Show next and prev buttons
    slideSpeed: 600,
    pagination: true,
    singleItem: true,
    navigationText:['<span class="npre"><i class="fa fa-arrow-left"></i></span>','<span class="nnext"><i class="fa fa-arrow-right"></i></span>']

  });
  
  
  $('.counter').counterUp({
    delay: 10,
    time: 1000
  });

  new WOW().init();
  
});


